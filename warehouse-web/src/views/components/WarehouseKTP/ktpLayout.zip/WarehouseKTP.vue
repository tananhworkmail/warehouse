<template>
  <WarehouseLayoutKTP>
    <template #default>
      <section class="ktp-page">
        <div ref="scrollRef" v-loading="loading" class="warehouse-scroll">
          <div
            class="warehouse-board"
            :style="{ width: `${ktpLayout.width}px`, height: `${ktpLayout.height}px` }"
          >
            <svg
              class="layout-layer"
              :viewBox="`0 0 ${ktpLayout.width} ${ktpLayout.height}`"
              aria-hidden="true"
            >
              <template v-for="shape in ktpLayout.shapes" :key="shape.id">
                <line
                  v-if="shape.type === 'line'"
                  class="wall-line"
                  :x1="shape.x1"
                  :y1="shape.y1"
                  :x2="shape.x2"
                  :y2="shape.y2"
                />
                <g v-else-if="shape.type === 'rect'">
                  <rect
                    :class="['shape-rect', `is-${shape.variant}`]"
                    :x="shape.x"
                    :y="shape.y"
                    :width="shape.w"
                    :height="shape.h"
                  />
                  <text
                    v-if="shape.text"
                    class="shape-text"
                    :x="shape.x + shape.w / 2"
                    :y="shape.y + shape.h / 2 - ((shape.text.split('\n').length - 1) * 7)"
                    text-anchor="middle"
                  >
                    <tspan
                      v-for="(line, index) in shape.text.split('\n')"
                      :key="`${shape.id}-${index}`"
                      :x="shape.x + shape.w / 2"
                      :dy="index === 0 ? 0 : 14"
                    >
                      {{ line }}
                    </tspan>
                  </text>
                </g>
                <circle
                  v-else-if="shape.type === 'circle'"
                  :class="['shape-circle', `is-${shape.variant}`]"
                  :cx="shape.cx"
                  :cy="shape.cy"
                  :r="shape.r"
                />
                <g v-else-if="shape.type === 'door'" class="door-shape">
                  <rect
                    :x="shape.x"
                    :y="doorPanelY(shape)"
                    :width="shape.size"
                    :height="doorPanelThickness"
                  />
                  <line
                    :x1="shape.x + 4"
                    :y1="doorPanelY(shape) + doorPanelThickness / 2"
                    :x2="shape.x + shape.size - 4"
                    :y2="doorPanelY(shape) + doorPanelThickness / 2"
                  />
                </g>
                <text
                  v-else-if="shape.type === 'text'"
                  :class="['layout-text', `is-${shape.variant}`]"
                  :x="shape.x"
                  :y="shape.y"
                  :text-anchor="shape.anchor || 'middle'"
                >
                  <tspan
                    v-for="(line, index) in shape.value.split('\n')"
                    :key="`${shape.id}-${index}`"
                    :x="shape.x"
                    :dy="index === 0 ? 0 : 16"
                  >
                    {{ line }}
                  </tspan>
                </text>
              </template>

              

              <polyline
                v-for="route in ktpLayout.escapeRoutes"
                :key="route.id"
                class="escape-route"
                :points="routeBodyPoints(route.points)"
              />
              <polygon
                v-for="route in ktpLayout.escapeRoutes"
                :key="`${route.id}-head`"
                class="escape-arrow-head"
                :points="routeArrowHeadPoints(route.points)"
              />
            </svg>

            <button
              v-for="item in rackItems"
              :key="item.id"
              :ref="(el) => setRackRef(item.id, el)"
              type="button"
              class="rack-cell"
              :class="[
                rackLabelClass(item.code),
                {
                  'is-horizontal': item.direction === 'horizontal',
                  'is-empty': getRack(item.code).status === 'empty',
                  'is-occupied': getRack(item.code).status === 'occupied',
                  'is-selected': selectedRack?.layoutId === item.id,
                },
              ]"
              :style="rackStyle(item)"
              @click="openRackDialog(item)"
            >
              <span class="rack-code">{{ item.code }}</span>
              <span class="qty-text">{{ formatQty(getRack(item.code).totalQty) }}</span>
            </button>
          </div>
        </div>

        <RackInformationDialogKTP
          v-model:dialog-visible="dialogVisible"
          :rack="selectedRack"
          @close="closeRackDialog"
        />
      </section>
    </template>
  </WarehouseLayoutKTP>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from "vue";
import axios from "axios";
import { ElMessage } from "element-plus";
import WarehouseLayoutKTP from "@/views/components/WarehouseKTP/WarehouseLayoutKTP.vue";
import RackInformationDialogKTP from "@/views/components/WarehouseKTP/RackInformationDialogKTP/index.vue";
import { ktpLayout } from "@/views/components/WarehouseKTP/ktpLayout";

const API_URL = import.meta.env.VITE_API_URL;
const API_BASE = `${API_URL}/warehouse-ktp`;

const loading = ref(false);
const dialogVisible = ref(false);
const selectedRack = ref(null);
const rackDataMap = ref(new Map());
const rackRefs = new Map();
let ktpEventSource = null;
let realtimeRefreshTimer = null;

const rackItems = computed(() =>
  ktpLayout.racks.map((item, index) => ({
    ...item,
    id: `${item.code}-${index}`,
  })),
);

const fetchRacks = async ({ silent = false } = {}) => {
  if (!silent) {
    loading.value = true;
  }
  try {
    const res = await axios.get(`${API_BASE}/racks`);
    applyRackData(res.data.data || []);
  } catch (err) {
    const message =
      err.response?.data?.message ||
      err.message ||
      "Khong tai duoc du lieu kho thanh pham";
    console.error("Load warehouse KTP racks failed:", err);
    ElMessage.error(message);
  } finally {
    if (!silent) {
      loading.value = false;
    }
  }
};

const applyRackData = (rows) => {
  const nextMap = new Map();
  rows.forEach((rack) => {
    nextMap.set(rack.rackCode, {
      rackCode: rack.rackCode,
      currentCode: null,
      status: Number(rack.totalQty || 0) > 0 ? "occupied" : "empty",
      totalQty: Number(rack.totalQty || 0),
      codebarCount: Number(rack.codebarCount || 0),
      sampleCodes: rack.sampleCodes || [],
    });
  });
  rackDataMap.value = nextMap;

  if (selectedRack.value?.rackCode) {
    const latestRack =
      nextMap.get(selectedRack.value.rackCode) ||
      getEmptyRack(selectedRack.value.rackCode);
    selectedRack.value = {
      ...latestRack,
      layoutId: selectedRack.value.layoutId,
    };
  }
};

const getEmptyRack = (rackCode) => ({
  rackCode,
  currentCode: null,
  status: "empty",
  totalQty: 0,
  codebarCount: 0,
  sampleCodes: [],
});

const getRack = (rackCode) => {
  return rackDataMap.value.get(rackCode) || getEmptyRack(rackCode);
};

const openRackDialog = (item) => {
  const rack = getRack(item.code);
  selectedRack.value = {
    ...rack,
    rackCode: item.code,
    layoutId: item.id,
  };
  dialogVisible.value = true;
};

const closeRackDialog = () => {
  dialogVisible.value = false;
  selectedRack.value = null;
};

const setRackRef = (id, el) => {
  if (el) rackRefs.set(id, el);
  else rackRefs.delete(id);
};

const rackStyle = (item) => ({
  left: `${item.x}px`,
  top: `${item.y}px`,
  width: `${item.w}px`,
  height: `${item.h}px`,
});

const getRackCodeParts = (rackCode) => {
  const match = String(rackCode).match(/^([A-Z]+)(\d+)$/);
  if (!match) {
    return { prefix: "", number: 0 };
  }

  return {
    prefix: match[1],
    number: Number(match[2]),
  };
};

const rackLabelClass = (rackCode) => {
  const { prefix, number } = getRackCodeParts(rackCode);

  if (prefix === "A" && number >= 29 && number <= 47) {
    return "label-right";
  }

  if (
    (prefix === "A" && number >= 13 && number <= 28) ||
    (prefix === "A" && number >= 48 && number <= 58) ||
    (prefix === "B" && number >= 1 && number <= 44)
  ) {
    return "label-bottom";
  }

  return "label-top";
};

const escapeArrowHeadLength = 16;
const escapeArrowHeadWidth = 18;

const formatSvgPoints = (points) => points.map(([x, y]) => `${x},${y}`).join(" ");

const getLastSegment = (points) => {
  const tip = points[points.length - 1];
  const previous = points[points.length - 2];
  const dx = tip[0] - previous[0];
  const dy = tip[1] - previous[1];
  const length = Math.hypot(dx, dy) || 1;

  return {
    tip,
    unitX: dx / length,
    unitY: dy / length,
  };
};

const routeBodyPoints = (points) => {
  if (points.length < 2) return formatSvgPoints(points);

  const { tip, unitX, unitY } = getLastSegment(points);
  const bodyEnd = [
    tip[0] - unitX * escapeArrowHeadLength,
    tip[1] - unitY * escapeArrowHeadLength,
  ];

  return formatSvgPoints([...points.slice(0, -1), bodyEnd]);
};

const routeArrowHeadPoints = (points) => {
  if (points.length < 2) return "";

  const { tip, unitX, unitY } = getLastSegment(points);
  const baseX = tip[0] - unitX * escapeArrowHeadLength;
  const baseY = tip[1] - unitY * escapeArrowHeadLength;
  const halfWidth = escapeArrowHeadWidth / 2;
  const perpendicularX = -unitY * halfWidth;
  const perpendicularY = unitX * halfWidth;

  return formatSvgPoints([
    tip,
    [baseX + perpendicularX, baseY + perpendicularY],
    [baseX - perpendicularX, baseY - perpendicularY],
  ]);
};

const doorPanelThickness = 10;

const doorPanelY = (door) =>
  door.direction === "up" ? door.y - doorPanelThickness : door.y;


const formatQty = (value) => Number(value || 0).toLocaleString("vi-VN");

const scheduleRealtimeRefresh = () => {
  if (realtimeRefreshTimer) {
    clearTimeout(realtimeRefreshTimer);
  }

  realtimeRefreshTimer = setTimeout(() => {
    fetchRacks({ silent: true });
  }, 250);
};

const connectWarehouseKTPRealtime = () => {
  if (!window.EventSource || !API_URL) {
    return;
  }

  ktpEventSource = new EventSource(`${API_URL}/sse`);
  ktpEventSource.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === "WAREHOUSE_KTP_RACKS_UPDATED") {
        scheduleRealtimeRefresh();
      }
    } catch (err) {
      console.warn("Invalid warehouse KTP realtime event:", err);
    }
  };
};

onMounted(() => {
  fetchRacks();
  connectWarehouseKTPRealtime();
});

onUnmounted(() => {
  if (ktpEventSource) {
    ktpEventSource.close();
  }
  if (realtimeRefreshTimer) {
    clearTimeout(realtimeRefreshTimer);
  }
});
</script>

<style lang="scss" scoped>
.ktp-page {
  min-height: 100%;
  background: #f4f7f5;
}

.warehouse-scroll {
  height: calc(100vh - 70px);
  overflow: auto;
  padding: 0;
  background: #f4f7f5;
}

.warehouse-board {
  position: relative;
  margin-top: -50px;
  background: #fffef8;
  transform-origin: top left;
}

.layout-layer {
  position: absolute;
  inset: 0;
  z-index: 1;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.wall-line {
  stroke: #1f2033;
  stroke-width: 4;
  stroke-linecap: square;
  vector-effect: non-scaling-stroke;
}

.escape-route {
  fill: none;
  stroke: #dc2626;
  stroke-width: 10;
  stroke-linecap: round;
  stroke-linejoin: round;
  vector-effect: non-scaling-stroke;
}

.escape-arrow-head {
  fill: #dc2626;
}

.shape-rect {
  fill: none;
  stroke: #334155;
  stroke-width: 2;
  vector-effect: non-scaling-stroke;
}

.shape-rect.is-machine,
.shape-rect.is-thin {
  fill: #eef8ff;
  stroke: #0284c7;
  stroke-width: 2;
}

.shape-circle.is-temperature-sensor {
  fill: #334155;
  stroke: none;
}

.door-shape {
  fill: #fffef8;
  stroke: #059669;
  stroke-width: 2;
  stroke-linecap: square;
  vector-effect: non-scaling-stroke;
}

.door-shape line {
  stroke-width: 1.5;
}

.shape-text,
.layout-text {
  fill: #263241;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 12px;
  font-weight: 700;
}

.layout-text.is-red-small,
.layout-text.is-delivery {
  fill: #b91c1c;
}

.layout-text.is-cfqc {
  font-family: "Times New Roman", Times, serif;
  font-size: 38px;
  font-weight: 500;
}

.layout-text.is-stairs {
  font-family: "Segoe UI", Arial, Helvetica, sans-serif;
  font-size: 14px;
  font-weight: 900;
}

.layout-text.is-map-title {
  font-family: "Times New Roman", Times, serif;
  font-size: 26px;
  font-weight: 900;
}

.layout-text.is-map-subtitle {
  font-family: "Times New Roman", Times, serif;
  font-size: 24px;
  font-weight: 700;
}

.rack-cell {
  position: absolute;
  z-index: 2;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1px;
  border: 1px solid #2f855a;
  border-radius: 2px;
  background: #00ff0d;
  color: #1f2933;
  cursor: pointer;
  overflow: visible;
  transition:
    border-color 0.15s ease,
    box-shadow 0.15s ease;

  &:hover {
    border-color: #0f766e;
    box-shadow: 0 0 0 2px rgba(15, 118, 110, 0.22);
    z-index: 4;
  }
}

.rack-cell.is-occupied {
  background: #00ff0d;
}

.rack-cell.is-empty {
  border-color: #94a3b8;
  background: #00ff0d
}

.rack-cell.is-selected {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.28);
  z-index: 5;
}

.rack-cell.is-horizontal {
  justify-content: center;
}

.rack-code {
  position: absolute;
  color: #dc2626;
  font-size: 8px;
  font-weight: 900;
  line-height: 1;
  pointer-events: none;
  white-space: nowrap;
}

.rack-cell.label-top .rack-code {
  bottom: calc(100% + 2px);
  left: 50%;
  transform: translateX(-50%);
}

.rack-cell.label-right .rack-code {
  top: 50%;
  left: calc(100% + 3px);
  transform: translateY(-50%);
}

.rack-cell.label-bottom .rack-code {
  top: calc(100% + 2px);
  left: 50%;
  transform: translateX(-50%);
}

.qty-text {
  color: #000000;
  font-size: 7px;
  font-weight: 900;
  line-height: 1;
  white-space: nowrap;
}
</style>
